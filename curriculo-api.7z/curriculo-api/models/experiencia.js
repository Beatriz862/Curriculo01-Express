'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Experiencia extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Experiencia.init({
    empresa: DataTypes.STRING,
    cargo: DataTypes.STRING,
    descricao: DataTypes.TEXT,
    ano_inicio: DataTypes.INTEGER,
    ano_fim: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Experiencia',
  });
  return Experiencia;
};